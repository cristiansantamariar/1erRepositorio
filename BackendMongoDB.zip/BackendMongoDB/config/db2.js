const mongoose = require('mongoose');
require('dotenv').config();

// Función para hacer la conexión 
const ConectarBD = () => {
    mongoose
    .connect(process.env.DB_MONGO)
    .then (()=> console.log("Estamos conectados con MongoDB"))
    .catch((err)=>console.error(err));
}

module.exports = ConectarBD;

