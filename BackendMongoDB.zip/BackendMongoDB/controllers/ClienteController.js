// exportamos nuestro modelo
const Cliente = require('../models/Cliente');

exports.agregarClientes = async (req, res) => {
    try {
        let clientes = new Cliente(req.body)
        await clientes.save();
        res.send(clientes);

    } catch (error) {
        console.log(error)
        res.status(500).send('Hubo un error al agregar un cliente')
    }
}

// mostrar clientes
exports.mostrarClientes = async (req, res) => {
    try {
        let clientes = await Cliente.find();
        res.json(clientes);

    } catch (error) {
        console.log(error)
        res.status(500).send('Hubo un error al mostrar los clientes')
    }
}

// mostrar un cliente 
exports.mostrar1cliente = async (req, res) => {
    try {
        let cliente = await Cliente.findById(req.params.id);
        if (!cliente) {
            return res.status(404).json({ msg: "No se encuentra el cliente con ese ID" });
        }
        res.json(cliente);

    } catch (error) {
        console.log(error)
        res.status(500).send('Hubo un error al mostrar el cliente');
    }
}

// funcion para eliminar clientes 


exports.eliminarClientes = async (req, res) => {
    try {
        let cliente = await Cliente.findById(req.params.id);
        if (!cliente) {
            return res.status(404).json({ msg: "El cliente no existe" });
        }

        await Cliente.findByIdAndDelete(req.params.id);
        res.json({ msg: "El cliente ha sido eliminado correctamente" });
    } catch (error) {
        console.log(error);
        res.status(500).json({ msg: "Hubo un error al eliminar el cliente en la base de datos" });
    }
}
// funcion actualizar Clientes


exports.actualizarClientes = async (req, res) => {
    try {
        let cliente = await Cliente.findById(req.params.id);
        if (!cliente) {
            return res.status(404).json({ msg: "El cliente no existe" });
        }

        await Cliente.findByIdAndDelete(req.params.id);
        res.json({ msg: "El cliente ha sido eliminado correctamente" });
    } catch (error) {
        console.log(error);
        res.status(500).json({ msg: "Hubo un error al eliminar el cliente en la base de datos" });
    }
}


/// funcion actualizar datos actualzarClientes

exports.modificarClientes = async (req, res) => {
    try {
        const { nombres, apellidos, documento, correo, telefono, direccion } = req.body;
        const cliente = await Cliente.findById(req.params.id);

        if (!cliente) {
            return res.status(404).json({ msg: "El cliente no existe" });
        }

        // Actualizar los campos del cliente
        cliente.nombres = nombres;
        cliente.apellidos = apellidos;
        cliente.documento = documento;
        cliente.correo = correo;
        cliente.telefono = telefono;
        cliente.direccion = direccion;

        // Guardar los cambios y devolver el cliente actualizado
        const clienteActualizado = await cliente.save();
        res.json(clienteActualizado);
    } catch (error) {
        console.log(error);
        res.status(500).json({ msg: "Hubo un error al actualizar el cliente en la base de datos" });
    }
}

