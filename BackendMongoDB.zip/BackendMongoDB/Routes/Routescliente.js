const express = require('express');
const Router = express.Router();
const ClienteController = require ('../controllers/ClienteController');


// aca van las rutas del crud
Router.post('/', ClienteController.agregarClientes);
Router.get('/', ClienteController.mostrarClientes );
Router.get('/:id', ClienteController.mostrar1cliente);
Router.delete('/:id', ClienteController.eliminarClientes);
Router.patch('/:id', ClienteController.modificarClientes);
//Router.patch('/:id', ClienteController.modificarClientes);
//Router.patch('/:id', ClienteController.modificarClientes);


module.exports = Router;
