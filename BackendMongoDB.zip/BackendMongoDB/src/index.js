const express = require('express');
const ConectarBD = require('../config/db2');
const cors = require('cors');


//Configuracion puerto servidor en la nube

const port = process.env.PORT || 4500;

// Configuración express y puerto
const app = express();
app.use(express.json());

// mongodb+srv://CristianCSR:1023019935@cluster0.fshrdoz.mongodb.net/Apiclientes


// Enlazamos la conexión de la base de datos
ConectarBD();
app.use(cors());

// Montamos el enrutador de clientes
app.use('/APIclientes/clientes', require('../Routes/Routescliente'));

// Se configura el puerto que va a tener nuestro servidor
app.listen(port, () => console.log('El servidor está conectado en http://127.0.0.1:4500/'));
app.post('/APIclientes/clientes', (req, res) => {
    // Código para manejar la solicitud POST a /API/clientes
  });
app.get('/', (req, res) => {
    res.send('Bienvenido, nuestro servidor está configurado');
});
