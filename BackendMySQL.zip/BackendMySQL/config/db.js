import { Sequelize } from "sequelize";

const BD = new Sequelize('citasbd', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
    port: 3306, // El puerto predeterminado de MySQL es 3306
});



export default BD;
