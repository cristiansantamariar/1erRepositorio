import express from "express";
import cors from "cors";
import BD from "../config/db.js";
import Rutas from "../routes/Rutas.js";

// Definimos la variable app para trabajar con express
const app = express();

// Configuración de middlewares
app.use(cors());
app.use(express.json());

// Configuración de las rutas
app.use('/citas', Rutas);

// Autenticación de la base de datos usando Sequelize
try {
    await BD.authenticate();
    console.log('Connection has been established successfully.');
} catch (error) {
    console.error('Unable to connect to the database: ', error);
}

// Ruta de prueba
app.get('/', (req, res) => {
    res.send("Hola mundo desde este Backend");
});

// Iniciamos el servidor en el puerto 3307
const PORT = process.env.PORT || 3303;
app.listen(PORT, () => {
    console.log(`El servidor está corriendo en http://localhost:${PORT}/`);
});
