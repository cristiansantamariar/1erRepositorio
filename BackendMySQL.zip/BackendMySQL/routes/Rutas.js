import express from 'express'; 

// importamos de nuestro controllador

import { agregarCitas, eliminarCita } from '../controllers/CitasController.js';
import { mostrarAllCitas } from'../controllers/CitasController.js';
import { mostrarCita } from '../controllers/CitasController.js';
import { modificarCita } from '../controllers/CitasController.js';



const router = express.Router(); 


// importamos funciones 
router.post('/', agregarCitas); 
router.get('/', mostrarAllCitas); 
router.get('/:id', mostrarCita); 
router.patch('/:id', modificarCita);
router.delete('/:id', eliminarCita); 

export default router;
