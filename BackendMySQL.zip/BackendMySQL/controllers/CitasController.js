// importamos el modelo 
import Citas from "../models/citas.js";

// modelo crud 
// creamos una funcion para agregar citas 
export const agregarCitas = async (req, res) => {
    try {
        // Crear la cita utilizando los datos del cuerpo de la solicitud (req.body)
        const nuevaCita = await Citas.create(req.body);

        // Enviar una respuesta JSON indicando que la cita fue creada exitosamente
        res.json({ msg: "Cita creada con éxito", cita: nuevaCita });
    } catch (error) {
        // Enviar una respuesta JSON con el mensaje de error en caso de que ocurra un error
        res.json({ msg: error.message });
    }
};

// creamos una funcion para mostrar las citas 



// Mostrar una cita por su ID
export const mostrarCita = async (req, res) => {
    try {
        // Buscar la cita por su ID en la base de datos
        const cita = await Citas.findByPk(req.params.id); 

        // Verificar si se encontró la cita
        if (cita) {
            // Enviar una respuesta JSON con la cita encontrada
            res.json({ cita });
        } else {
            // Si no se encontró la cita, enviar un mensaje de error con el código de estado 404
            res.status(404).json({ msg: "Cita no encontrada" });
        }
    } catch (error) {
        // Enviar una respuesta JSON con el mensaje de error en caso de que ocurra un error
        res.status(500).json({ msg: "Error al obtener la cita: " + error.message });
    }
};

// Mostrar todas las citas
export const mostrarAllCitas = async (req, res) => {
    try {
        // Buscar todas las citas en la base de datos
        const citas = await Citas.findAll();

        // Enviar una respuesta JSON con todas las citas encontradas
        res.json({ citas });
    } catch (error) {
        // Enviar una respuesta JSON con el mensaje de error en caso de que ocurra un error
        res.status(500).json({ msg: error.message });
    }
};


// funcion modificar cita

export const modificarCita = async (req, res) => {
    try {
        const resultado = await Citas.update(req.body, {
            where: { id: req.params.id } 
        });

        if (resultado[0] !== 0) {
            res.json({ msg: "Cita modificada exitosamente" });
        } else {
            
            res.status(404).json({ msg: "Cita no encontrada" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
};


// funcion eliminar cita

export const eliminarCita = async (req, res) => {
    try { 
        await Citas.destroy({
            where:{id: req.params.id}
        })
        res.json({msg: "Se elimino la cita"})
    } catch (error){
        res.json({msg: error.message})
    }
}